const defaults={zoom:{value:3},fitWorkArea:{checked:true},cols:{value:1},rows:{value:1},ox:{value:0},oy:{value:0},capeDelay:{value:150},hideBody:{checked:false},anchors:{checked:true},follow:{checked:true}};const $=id=>document.getElementById(id)||defaults[id], c=$('canvas'),ctx=c.getContext('2d');let data,body,head,skills=[],action='stand1',frame=0,elapsed=0,paused=false,dir=1,x=0,y=0,vy=0,capes=[],capeTime=0,fxTime=0,selected=null,locked=false,preview=false,frameDirection=1;const starActions={throwStar1:'swingO1',throwStar2:'swingO2',throwStar3:'swingO3'};let basicAttacks=null;let stars=[],starCycles=0,throwConfig,shadowPartnerData;const images=new Map(),keys=new Set();const aliases={"walk1": "걷기 1", "walk2": "걷기 2", "stand1": "서 있기 1", "stand2": "서 있기 2", "alert": "경계", "swingO1": "한손 휘두르기 1", "swingO2": "한손 휘두르기 2", "swingO3": "한손 휘두르기 3", "swingOF": "한손 휘두르기 마무리", "swingT1": "두손 휘두르기 1", "swingT2": "두손 휘두르기 2", "swingT3": "두손 휘두르기 3", "swingTF": "두손 휘두르기 마무리", "swingP1": "폴암 휘두르기 1", "swingP2": "폴암 휘두르기 2", "swingPF": "폴암 휘두르기 마무리", "stabO1": "한손 찌르기 1", "stabO2": "한손 찌르기 2", "stabOF": "한손 찌르기 마무리", "stabT1": "두손 찌르기 1", "stabT2": "두손 찌르기 2", "stabTF": "두손 찌르기 마무리", "shoot1": "발사 1", "shoot2": "발사 2", "shootF": "발사 마무리", "proneStab": "엎드려 공격", "prone": "엎드리기", "heal": "치유", "fly": "비행", "jump": "점프", "sit": "앉기", "ladder": "사다리", "rope": "밧줄", "dead": "사망", "savage": "세비지 블로우", "alert2": "경계 2", "alert3": "경계 3", "alert4": "경계 4", "alert5": "경계 5", "alert6": "경계 6", "paralyze": "마비", "ladder2": "사다리 2", "rope2": "밧줄 2", "shoot6": "발사 6", "magic1": "마법 시전 1", "magic2": "마법 시전 2", "magic3": "마법 시전 3", "magic4": "마법 시전 4", "burster1": "버스터 1", "burster2": "버스터 2", "avenger": "어벤저", "assaulter": "어썰터", "prone2": "엎드리기 2", "assassination": "암살", "assassinationS": "암살 마무리", "rush": "돌진 1", "rush2": "돌진 2", "sanctuary": "생츄어리", "meteor": "메테오", "blizzard": "블리자드", "genesis": "제네시스", "brandish1": "브랜디쉬 1", "brandish2": "브랜디쉬 2", "ninjastorm": "닌자 스톰", "chainlightning": "체인 라이트닝", "blast": "블래스트", "showdown": "쇼다운", "smokeshell": "연막탄", "holyshield": "홀리 실드", "resurrection": "리저렉션", "straight": "스트레이트", "handgun": "권총 공격", "somersault": "써머솔트 킥", "doublefire": "더블 파이어", "triplefire": "트리플 파이어", "fake": "페이크", "doubleupper": "더블 어퍼", "eburster": "에너지 버스터", "screw": "스크류 펀치", "dash": "대시", "backspin": "백스핀 블로우", "eorb": "에너지 오브", "dragonstrike": "드래곤 스트라이크", "airstrike": "에어 스트라이크", "edrain": "에너지 드레인", "octopus": "옥토퍼스", "backstep": "백스텝 샷", "timeleap": "타임 리프", "shot": "사격", "recovery": "리커버리", "fist": "피스트", "fireburner": "파이어 버너", "coolingeffect": "쿨링 이펙트", "homing": "호밍", "rapidfire": "래피드 파이어", "ghostwalk": "유령 걷기", "ghoststand": "유령 서 있기", "ghostjump": "유령 점프", "ghostproneStab": "유령 엎드려 공격", "ghostladder": "유령 사다리", "ghostrope": "유령 밧줄", "ghostfly": "유령 비행", "ghostsit": "유령 앉기", "cannon": "캐논", "torpedo": "토르페도", "darksight": "다크 사이트"};const getFrames=()=>Object.keys(body[action]||{}).filter(k=>/^\d+$/.test(k)).sort((a,b)=>a-b);function resolve(root,path,n){if(!n?.uol)return n;let p=path.split('/');p.pop();for(const s of n.uol.split('/')){if(s==='..')p.pop();else if(s!=='.')p.push(s)}let v=root;for(const s of p)v=v?.[s];return resolve(root,p.join('/'),v)}function node(root,path){let n=root;for(const k of path.split('/'))n=n?.[k];return resolve(root,path,n)}function img(src){if(!src)return; if(!images.has(src)){const i=new Image();i.src=src;images.set(src,i)}return images.get(src)}function setAction(a,lock=false,repeat=false){if(!body[a])return;starCycles=0;$('starPicker').hidden=!starActions[a];action=a;frame=0;frameDirection=1;elapsed=0;locked=lock;preview=repeat;selectEffect(a);if(starActions[a])selected=skills.find(s=>s.id===($('throwSkill').value==='triple'?'4121007':'4001344'))||null;$('action').value=a;window.codyEditor?.sync();const st=JSON.parse(localStorage.getItem('cape-'+a)||'null');if(st)for(const [k,v]of Object.entries(st))$(k).value=v}function bodyPose(a,f){let key=a+'/'+f,seen=new Set(),move={x:0,y:0},flip=0;while(true){if(seen.has(key))throw new Error('동작 순환 참조: '+key);seen.add(key);const n=node(body,key);if(n?.move){move.x+=n.move.x||0;move.y+=n.move.y||0}if(n?.flip)flip^=1;if(!n?.action)return {path:key,frame:n||{},move,flip};key=n.action+'/'+(n.frame??0);}}function drawPart(n,dx=0,dy=0){if(!n?.src)return;const im=img(n.src);if(im?.complete&&im.naturalWidth)ctx.drawImage(im,Math.round(dx-(n.origin?.x||0)),Math.round(dy-(n.origin?.y||0)))}function framesOf(n){return Object.keys(n||{}).filter(k=>/^\d+$/.test(k)).sort((a,b)=>a-b).map(k=>n[k])}function cast(repeat=true){const s=selected;if(!s)return;const a=skillActions(s).find(a=>typeof a==='string'&&body[a]);if(a)setAction(a,true,repeat);fxTime=0}function skillActions(s){return typeof s.actions==='string'?[s.actions]:Object.values(s.actions||{});}function isBasicAttack(a){return /^(swing[OTP][123F]|stab[OT][12F]|proneStab)$/.test(a)}function actionTime(){return getFrames().slice(0,frame).reduce((t,k)=>t+Math.abs(body[action][k].delay||100),0)+elapsed}function drawBasicAttack(){
 if(!isBasicAttack(action)||!$('effectsVisible').checked)return;
 const entry=basicAttacks?.actions?.[action];if(!entry)return;
 const fs=getFrames(),now=actionTime();
 for(const [trigger,sequence]of Object.entries(entry.frames)){
  const index=fs.indexOf(trigger);if(index<0)continue;
  let t=now-fs.slice(0,index).reduce((sum,k)=>sum+Math.abs(body[action][k].delay||100),0);if(t<0)continue;
  for(const n of framesOf(sequence)){
   const duration=Math.abs(n.delay||100);if(t<duration){ctx.save();ctx.globalAlpha=((n.a0??255)+((n.a1??255)-(n.a0??255))*t/duration)/255;drawPart(n);ctx.restore();break;}t-=duration;
  }
 }
}function selectEffect(a){if(isBasicAttack(a)){selected=null;fxTime=0;return;}const preferred={savage:'4201005',genesis:'2321008'};selected=skills.find(s=>s.id===preferred[a])||skills.find(s=>skillActions(s).includes(a)&&Object.keys(s.effects||{}).some(k=>k.startsWith('effect')))||null;fxTime=0;}function effectFrames(n,variant=0){if(n?.uol)return [];const direct=framesOf(n);if(direct.some(f=>f?.src))return direct.filter(f=>f?.src);const group=n?.[String(variant)];if(group)return effectFrames(group,0);return [];}function drawEffects(behind=false){if(!selected||!$('effectsVisible').checked)return;const variant=Math.max(0,skillActions(selected).indexOf(action));for(const [kind,effect]of Object.entries(selected.effects||{})){if(!kind.startsWith('effect')||(Number(effect.z||0)<0)!==behind)continue;const seq=effectFrames(effect,variant);let t=fxTime;for(const n of seq){const duration=Math.abs(n.delay||100);if(t<duration){ctx.save();if(n.a0!==undefined||n.a1!==undefined)ctx.globalAlpha=((n.a0??255)+((n.a1??255)-(n.a0??255))*t/duration)/255;drawPart(n);ctx.restore();break}t-=duration}}}function tick(dt){let fs=getFrames();if(!paused){elapsed+=dt*+$('speed').value;capeTime+=dt;fxTime+=dt*(starActions[action]?+$('speed').value:1);let guard=0;while(elapsed>=Math.abs(body[action]?.[fs[frame]]?.delay||100)&&guard++<20){elapsed-=Math.abs(body[action]?.[fs[frame]]?.delay||100);if(/^(stand[12]|ghoststand|alert[2-6]?)$/.test(action)&&fs.length>1){frame+=frameDirection;if(frame>=fs.length){frameDirection=-1;frame=fs.length-2}else if(frame<0){frameDirection=1;frame=1}}else frame=(frame+1)%Math.max(1,fs.length);if(frame===0&&starActions[action])starCycles++;if(frame===0&&preview)fxTime=0;if(frame===0&&locked&&!preview){locked=false;setAction('stand1');break}}if(!locked&&!window.codyEditor?.editing){let want=keys.has('ArrowDown')?'prone':keys.has('ArrowLeft')||keys.has('ArrowRight')?'walk1':'stand1';if(y<0)want='jump';if(action!==want&&!paused&&keys.size)setAction(want);if(keys.has('ArrowLeft')){x-=dt*.14;dir=-1}if(keys.has('ArrowRight')){x+=dt*.14;dir=1}}vy+=dt*.0015;y+=vy*dt;if(y>0){y=0;vy=0;if(action==='jump'&&!preview)setAction('stand1')}x=Math.max(-110,Math.min(110,x));}fs=getFrames();frame%=Math.max(1,fs.length);const width=c.clientWidth,height=c.clientHeight;c.width=width*devicePixelRatio;c.height=height*devicePixelRatio;ctx.scale(devicePixelRatio,devicePixelRatio);ctx.fillStyle='#b9d6c2';ctx.fillRect(0,0,width,height);ctx.strokeStyle='#abc9b4';for(let i=0;i<width;i+=30){ctx.beginPath();ctx.moveTo(i,0);ctx.lineTo(i,height);ctx.stroke()}const rendered=bodyPose(action,fs[frame]);const b=rendered.frame;const bp=node(body,rendered.path+'/body')||node(body,rendered.path+'/0');const nav=bp?.map?.navel||{x:0,y:0};const neck=bp?.map?.neck||{x:0,y:-30};let zoom=+$('zoom').value,floor=height*.76;const work=window.codyEditor?.current(action,frame);if(work&&$('fitWorkArea').checked){const im=work.canvas,origin=work.origin||window.codyEditor.document.origin||{x:im.width/2,y:im.height/2};zoom=Math.min(zoom,(width-36)/im.width,(height-36)/im.height);floor=height/2-(nav.y-origin.y+im.height/2)*zoom}if(window.codyEditor?.camera?.manual)zoom=window.codyEditor.camera.zoom;const viewX=width/2+x*zoom+(window.codyEditor?.camera?.x||0),viewY=floor+y*zoom+(window.codyEditor?.camera?.y||0);ctx.fillStyle='#7e9b73';ctx.fillRect(0,floor,width,height-floor);ctx.fillStyle='#5f7d57';ctx.fillRect(0,floor+5,width,5);ctx.save();ctx.translate(viewX,viewY);ctx.scale(-dir*zoom,zoom);ctx.imageSmoothingEnabled=false;drawEffects(true);drawShadowPartner();drawCharacterPose(rendered,frame,{viewX,viewY,zoom,dir});drawEffects(false);drawBasicAttack();drawStars();if($('anchors').checked){ctx.strokeStyle='#e45639';ctx.lineWidth=1/zoom;ctx.beginPath();ctx.moveTo(-5,0);ctx.lineTo(5,0);ctx.moveTo(0,-5);ctx.lineTo(0,5);ctx.stroke()}ctx.restore();$('timeline').max=Math.max(0,fs.length-1);$('timeline').value=frame;$('state').textContent=(aliases[action]||action)+' · '+(frame+1)+' / '+fs.length;$('info').textContent=`동작: ${aliases[action]}   프레임: ${frame+1}   시간: ${b.delay||100}ms\n몸체 영점: ${JSON.stringify(bp?.origin||{})}   몸체 연결점: ${JSON.stringify(nav)}`;}
(async()=>{[data,skills,stars,throwConfig,shadowPartnerData,basicAttacks]=await Promise.all([fetch('character.json?v=6').then(r=>r.json()),fetch('skills.json?v=6').then(r=>r.json()),fetch('stars.json?v=19').then(r=>r.json()),fetch('throw-config.json?v=21').then(r=>r.json()),fetch('shadow-partner.json?v=20').then(r=>r.json()),fetch('basic-attacks.json?v=25').then(r=>r.json())]);body=data['00002000.img'];head=data['00012000.img'];for(const [a,source] of Object.entries(starActions)){body[a]=Object.fromEntries(Object.entries(body[source]).filter(([k])=>/^\d+$/.test(k)).map(([k,n])=>[k,{action:source,frame:+k,delay:throwConfig.motions[source].delays[+k]}]));aliases[a]='표창 던지기 '+a.slice(-1);}$('starType').replaceChildren(...stars.map(s=>new Option(s.name,s.id)));$('starType').value=stars.some(s=>s.id==='2070006')?'2070006':stars[0]?.id;const acts=Object.keys(body).filter(k=>k!=='info');$('action').replaceChildren(...acts.map(a=>new Option(aliases[a],a)));for(const a of (window.CapePSD?.layout.map(v=>v[0])||['stand1','walk1','jump','prone','swingO1','ladder'])){const b=document.createElement('button');b.textContent=aliases[a];b.onclick=()=>setAction(a,true,true);$('presets').append(b)}for(const a of Object.keys(starActions)){const starButton=document.createElement('button');starButton.textContent=aliases[a];starButton.onclick=()=>setAction(a,true,true);$('presets').append(starButton);}$('state').textContent='캐릭터 이미지 준비 중';const sources=new Set();function collect(n){if(n&&typeof n==='object'){if(n.src)sources.add(n.src);for(const v of Object.values(n))collect(v)}}collect(data);collect(basicAttacks);collect(stars);collect(shadowPartnerData);for(const sk of skills)for(const [k,v]of Object.entries(sk.effects||{}))if(k.startsWith('effect'))collect(v);const failures=[];await Promise.all([...sources].map(src=>new Promise(resolve=>{const im=img(src);if(im.complete&&im.naturalWidth)return resolve();im.onload=resolve;im.onerror=()=>{failures.push(src);resolve()}})));if(failures.length)throw new Error('캐릭터 이미지 '+failures.length+'개를 불러오지 못했습니다. 새로고침해 주세요.');setAction('stand1');let prev=performance.now();function loop(now){tick(Math.min(50,now-prev));prev=now;requestAnimationFrame(loop)}requestAnimationFrame(loop)})().catch(e=>{$('state').textContent='데이터 로드 실패: '+e.message});$('action').onchange=e=>setAction(e.target.value,true,true);$('play').onclick=()=>{paused=!paused;$('play').textContent=paused?'재생':'일시정지'};function step(n){paused=true;$('play').textContent='재생';frame=(frame+n+getFrames().length)%getFrames().length;elapsed=0}$('next').onclick=()=>step(1);$('prev').onclick=()=>step(-1);$('timeline').oninput=e=>{paused=true;frame=+e.target.value};$('flip').onclick=()=>dir*=-1;$('reset').onclick=()=>{x=0;y=0;vy=0;if(window.codyEditor?.camera)window.codyEditor.camera={zoom:1,x:0,y:0,manual:false};setAction('stand1')};$('speed').oninput=e=>$('speedText').textContent=e.target.value+'×';window.onkeydown=e=>{if(window.codyEditor?.shortcut(e))return;if(['INPUT','SELECT','TEXTAREA'].includes(document.activeElement.tagName))return;if(['ArrowLeft','ArrowRight','ArrowDown',' ','Control'].includes(e.key))e.preventDefault();keys.add(e.key);if(e.repeat)return;if(e.key===' '&&y===0){vy=-.55;setAction('jump')}if(e.key==='Control'&&!window.codyEditor?.document)setAction(keys.has('ArrowDown')?'proneStab':'swingO1',true);if(e.key==='1')cast(false);if(e.key.toLowerCase()==='p')$('play').click()};window.onkeyup=e=>{keys.delete(e.key);if(!keys.size&&!locked&&y===0&&body)setAction('stand1')};window.onblur=()=>keys.clear();


function throwTiming(){
 const fs=getFrames(),durations=fs.map(f=>Math.abs(body[action][f].delay||100));
 return {fs,durations,cycle:durations.reduce((a,b)=>a+b,0),time:durations.slice(0,frame).reduce((a,b)=>a+b,0)+elapsed};
}
function drawCharacterPose(pose,poseFrame,stage=null){
 const b=pose.frame,bp=node(body,pose.path+'/body')||node(body,pose.path+'/0');
 const nav=bp?.map?.navel||{x:0,y:0},neck=bp?.map?.neck||{x:0,y:-30};
 ctx.save();ctx.translate(pose.move.x,pose.move.y);if(pose.flip)ctx.scale(-1,1);
 if(!$('hideBody').checked){
  drawPart(bp);const h=node(head,pose.path+'/head')||node(head,'front/head');
  drawPart(h,neck.x-(h?.map?.neck?.x||0),neck.y-(h?.map?.neck?.y||0));
  for(const k of Object.keys(b)){
   if(['body','face','delay'].includes(k))continue;
   const n=node(body,pose.path+'/'+k);
   if(n?.src&&n!==bp){const a=n.map?.navel||nav;drawPart(n,nav.x-a.x,nav.y-a.y)}
  }
 }
 if(window.codyEditor?.document){
  const cel=window.codyEditor.current(action,poseFrame);
  if(cel){
   const im=cel.canvas,anchor=cel.origin||window.codyEditor.document.origin||{x:im.width/2,y:im.height/2};
   const dx=Math.round(-anchor.x+nav.x),dy=Math.round(-anchor.y+nav.y);ctx.drawImage(im,dx,dy);
   if(stage){
    const {viewX,viewY,zoom,dir}=stage;
    window.codyEditor.stage={x:viewX-dir*zoom*pose.move.x,y:viewY+zoom*pose.move.y,sx:-dir*zoom*(pose.flip?-1:1),sy:zoom,dx,dy,cel};
    window.codyEditor.overlay(ctx,cel,dx,dy);
   }
  }
 }
 ctx.restore();
}
function shadowPartnerFrame(){
 const {fs,durations,cycle,time}=throwTiming();
 const delay=throwConfig.runtimeClient.shadowPoseDelayMs;
 let t=starCycles?((time-delay)%cycle+cycle)%cycle:Math.max(0,time-delay),f=0;
 while(f<fs.length-1&&t>=durations[f]){t-=durations[f];f++}
 return shadowPartnerData.actions[starActions[action]]?.[fs[f]];
}
function drawShadowPartner(){
 if(!starActions[action]||!$('shadowPartner').checked)return;
 // Special sprites already have the complete silhouette and per-pose placement.
 // WZ supplies each bitmap origin; the original client supplies the separate rear layer offset.
 const offset=throwConfig.runtimeClient.shadowOffset;drawPart(shadowPartnerFrame(),offset.x,offset.y);
}
// Bitmap origins/delays and attack frames are WZ data. Travel is a separately documented runtime reference.
function bodyAnchor(a,f){
 const pose=bodyPose(a,f),part=node(body,pose.path+'/body')||node(body,pose.path+'/0');
 const navel=part?.map?.navel||{x:0,y:0},sign=pose.flip?-1:1;
 return {x:pose.move.x+sign*navel.x,y:pose.move.y+navel.y};
}
function starFlight(copy=0){
 const ref=throwConfig.runtimeClient,rule=throwConfig.spawnAnchor;
 const attackFrame=throwConfig.motions[starActions[action]].attackFrame;
 // Freeze the body anchor at the release pose, including shots that continue into the next loop.
 const origin=bodyAnchor(action,attackFrame),base=bodyAnchor(rule.referenceAction,rule.referenceFrame);
 const dx=origin.x-base.x,dy=origin.y-base.y;
 const partner=copy?ref.shadowOffset:{x:0,y:0};
 const x=ref.spawn.x+dx+partner.x,y=ref.spawn.y+dy+partner.y;
 const targetX=ref.emptyTargetX+dx+partner.x,distance=Math.abs(targetX-x);
 const speed=1/ref.millisecondsPerPixel;
 return {x,y,speed,lifetime:distance*ref.millisecondsPerPixel};
}
function drawStars(){
 if(!starActions[action])return;
 const star=stars.find(s=>s.id===$('starType').value);
 if(!star?.frames.length)return;
 const {durations,cycle,time}=throwTiming(),mode=$('throwSkill').value==='triple'?'triple':'lucky';
 const count=throwConfig.skills[mode].bulletCount,copies=$('shadowPartner').checked?2:1;
 const attackFrame=throwConfig.motions[starActions[action]].attackFrame;
 const firstRelease=durations.slice(0,attackFrame).reduce((sum,d)=>sum+d,0),runtime=throwConfig.runtimeClient;
 for(let copy=0;copy<copies;copy++)for(let shot=0;shot<count;shot++){
  const flight=starFlight(copy),release=firstRelease+(shot+copy*count)*runtime.shotSpacingMs;
  for(let prior=0;prior<=Math.min(starCycles,Math.ceil((flight.lifetime+release)/cycle));prior++){
   const age=time-release+prior*cycle;
   if(age<0||age>=flight.lifetime)continue;
   const length=star.frames.reduce((sum,n)=>sum+Math.abs(n.delay||100),0);
   let t=age%length,n=star.frames[0];
   for(const f of star.frames){n=f;if(t<Math.abs(f.delay||100))break;t-=Math.abs(f.delay||100)}
   ctx.save();if(copy)ctx.globalAlpha=.65;
   drawPart(n,flight.x-age*flight.speed,flight.y);ctx.restore();
  }
 }
}
$('starType').onchange=()=>{starCycles=0;};
$('throwSkill').onchange=()=>{if(starActions[action])setAction(action,locked,preview);};
$('shadowPartner').onchange=()=>{if(starActions[action])setAction(action,locked,preview);};
